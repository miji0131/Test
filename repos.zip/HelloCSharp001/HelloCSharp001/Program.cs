﻿using System; //java의 import와 같은 것 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloCSharp001
{
    internal class Program
    { //소괄호() 중괄호{}(brace) 대괄호 [] 

        static void Main(string[] args)
        {
            //cw 쓰고 tab키 두 번
            //주석은 따라 적지 말 것(타자 빠르시면 적으셔도 됨)
            Console.WriteLine("Hello World"); //ctrl f5 눌러서 실행
        }
    }
}
