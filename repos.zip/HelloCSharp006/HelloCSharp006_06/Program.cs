﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*          1. Rectangle class를 만들고 width, height 멤버(=인스턴스 변수) 만든다.

            2. getArea() 메서드(=인스턴스 메서드)
            getArea(int w, int h) 메서드(=클래스 메서드) 두 개 만든다.
            둘 다 반환형은 int이다.

            3. Random 이용해서 Winform에서 숫자 맞추기 게임 간단하게
            만들기 (1~10 중 하나의 값 입력받고 정답 확인)

            4. Random 이용해서 가위 바위 보 게임 만들어 보기

            5. 3번에 타이머를 이용해서 시간 제한 추가해보기

            6. 보물 찾기 게임 만들기(지뢰 찾기랑 유사함)

            7. 6번을 하되, 타이머를 추가하여 시간 제한 추가하기*/

namespace HelloCSharp006_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rectangle r1 = new Rectangle();
            r1.width = 10;
            r1.height = 3;

            Rectangle r2 = new Rectangle() { width = 5, height = 7 };
            Console.WriteLine(r1.getArea());
            Console.WriteLine(r2.getArea());
            Console.WriteLine(Rectangle.getArea(8, 4));
        }
    }
}
