﻿namespace HelloCSharp006_02
{
    public class Student
    {
        public string name { get; set; }
        public int grade { get; set; }
    }
}