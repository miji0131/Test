﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloCSharp006_04
{
    public class Test2
    {
        public static int power(int x)
        {
            return x * x;
        }
        public static int Multi(int x, int y)
        {
            return x * y;
        }
        public static void print()
        {
            Console.WriteLine("메시지를 출력합니다.");
        }
    }
}
